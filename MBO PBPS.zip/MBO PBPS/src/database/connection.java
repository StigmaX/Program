/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;
import java.sql.*;
import com.mysql.jdbc.Driver;
/**
 *
 * @author ASUS
 */
public class connection {
    private static Connection koneksi;
    public static Connection GetConnection()throws SQLException{
        if(koneksi==null){
            new Driver();
            koneksi=DriverManager.getConnection("jdbc:mysql://localhost:3306/pbps","root","");
        }
        return koneksi;
    }
}
