-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.38-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table pbps.absensi
CREATE TABLE IF NOT EXISTS `absensi` (
  `Absensi` varchar(20) NOT NULL,
  `Mapel` varchar(50) NOT NULL,
  `Siswa` varchar(50) NOT NULL,
  `Tanggal` date NOT NULL,
  `Jam` time NOT NULL,
  KEY `FK_absensi_mapel` (`Mapel`),
  KEY `FK_absensi_siswa` (`Siswa`),
  CONSTRAINT `FK_absensi_mapel` FOREIGN KEY (`Mapel`) REFERENCES `mapel` (`Nama`) ON UPDATE NO ACTION,
  CONSTRAINT `FK_absensi_siswa` FOREIGN KEY (`Siswa`) REFERENCES `siswa` (`Nama`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pbps.absensi: ~4 rows (approximately)
/*!40000 ALTER TABLE `absensi` DISABLE KEYS */;
INSERT INTO `absensi` (`Absensi`, `Mapel`, `Siswa`, `Tanggal`, `Jam`) VALUES
	('Ada', 'Matematika', 'Ilman M. Difa', '2020-03-19', '10:10:44'),
	('Tidak Ada', 'Matematika', 'Wildan Kusnaedi', '2020-03-20', '12:30:59'),
	('Ada', 'Pancasila', 'Rizki Maulana', '2020-01-19', '07:00:00'),
	('Tidak Ada', 'Bahasa', 'Fadil Fauzi S.', '2020-03-21', '09:00:00');
/*!40000 ALTER TABLE `absensi` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
