-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.38-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table pbps.guruajar
CREATE TABLE IF NOT EXISTS `guruajar` (
  `No. Induk` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Wali` varchar(30) NOT NULL,
  PRIMARY KEY (`No. Induk`),
  KEY `Nama` (`Nama`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table pbps.guruajar: ~4 rows (approximately)
/*!40000 ALTER TABLE `guruajar` DISABLE KEYS */;
INSERT INTO `guruajar` (`No. Induk`, `Nama`, `Wali`) VALUES
	(1, 'danliw', 'A1'),
	(2, 'Nadliw', 'A2'),
	(3, 'Mega', 'B1'),
	(4, 'Doni', 'A3');
/*!40000 ALTER TABLE `guruajar` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
